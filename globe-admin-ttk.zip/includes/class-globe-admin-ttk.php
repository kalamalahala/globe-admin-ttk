<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://github.com/kalamalahala/
 * @since      1.0.0
 *
 * @package    Globe_Admin_Ttk
 * @subpackage Globe_Admin_Ttk/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Globe_Admin_Ttk
 * @subpackage Globe_Admin_Ttk/includes
 * @author     Tyler Karle <tyler.karle@icloud.com>
 */
class Globe_Admin_Ttk {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Globe_Admin_Ttk_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'GLOBE_ADMIN_TTK_VERSION' ) ) {
			$this->version = GLOBE_ADMIN_TTK_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'globe-admin-ttk';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Globe_Admin_Ttk_Loader. Orchestrates the hooks of the plugin.
	 * - Globe_Admin_Ttk_i18n. Defines internationalization functionality.
	 * - Globe_Admin_Ttk_Admin. Defines all hooks for the admin area.
	 * - Globe_Admin_Ttk_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-globe-admin-ttk-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-globe-admin-ttk-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-globe-admin-ttk-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-globe-admin-ttk-public.php';

		$this->loader = new Globe_Admin_Ttk_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Globe_Admin_Ttk_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Globe_Admin_Ttk_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Globe_Admin_Ttk_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		// Create sidebar menu, submenu, and top level menu
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'create_admin_menu' );
		// TODO: Add admin bar menu and submenu pages
		// $this->loader->add_action( 'admin_bar_menu', $plugin_admin, 'create_admin_bar_menu' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Globe_Admin_Ttk_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Globe_Admin_Ttk_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	/**
	 * Create admin menu hook
	 * 
	 * Points to: globe_life_admin_menu_page()
	 */
	public function create_admin_menu() {
		// Top level menu item for sidebar menu
		add_menu_page(
			'Globe Life Administration Plugin',
			'Globe Life',
			'manage_options',
			'globe-life-admin-menu',
			array( $this, 'globe_life_admin_menu_page' ),
			'dashicons-admin-site',
			58
		);

		// Submenu item for sidebar menu
		add_submenu_page(
			'globe-life-admin-menu',
			'Globe Life Admin Submenu',
			'Submenu',
			'manage_options',
			'globe-life-admin-submenu',
			array( $this, 'globe_life_admin_submenu_page' )
		);
	}

	public function globe_life_admin_menu_page() {
		// buffer
		ob_start();
		include_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/partials/globe-life-admin-menu-page.php';
		$output = ob_get_clean();
		echo $output;
	}
}
